import javax.xml.validation.SchemaFactoryConfigurationError;

public class Main {

    public static void main(String[] args) {
        var numero = 0;

        if (numero == 0){
            System.out.println("Es: 0");
        } else if (numero > 0){
            System.out.println("Es positivo");
        }else if (numero < 0){
            System.out.println("Es negativo");
        }

        int numeroWhile = 0;

        while (numeroWhile <3){
            System.out.println("El númeroWhile:"+numeroWhile);
            numeroWhile = numeroWhile + 1;
        }

        int DoWhile = 2;

        do {
            System.out.println("El número DoWhile:"+DoWhile);
            DoWhile = DoWhile + 1;
        } while (DoWhile < 3);


        int valores[] = {0, 1, 2, 3, 4};

        for (int  numeroFor = 0;  numeroFor <= 3;  numeroFor++){
            System.out.println("El número For:"+valores[numeroFor]);
        }

        var estacion = "otoño";

        switch (estacion){
            case "verano":
                System.out.println("es verano!");
                break;
            case "invierno":
                System.out.println("es invierno");
                break;
            default:
                System.out.println("Ni verano, ni invierno");
        }

    }
}


