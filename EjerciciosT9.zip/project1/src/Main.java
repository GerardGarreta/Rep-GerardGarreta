public class Main {

    public static void main(String[] args) {

        System.out.println("CLIENTE: ");
        Cliente cliente = new Cliente();
        cliente.Edad(33);
        cliente.Nombre("Carla");
        cliente.Telefono(666666666);
        cliente.credito(100);


        System.out.println(" ");


        System.out.println("TRABAJADOR: ");
        Trabajador trabajador = new Trabajador();
        trabajador.Edad(40);
        trabajador.Nombre("Rosa");
        trabajador.Telefono(604050504);
        trabajador.salario(2400);

    }
}

    class Persona {

        public void Edad(int cuantaEdad){
            System.out.println("Edad: "+cuantaEdad);

        }
        public void Nombre(String nombre){
            System.out.println("Nombre: "+nombre);
        }
        public  void Telefono(int numTelefono){
            System.out.println("NUMUERTO TELF.:"+numTelefono);
        }
    }


    class Cliente extends Persona {
    int credito;

        public void credito(int numeroCredito) {
            System.out.println("Credito: "+ numeroCredito);
        }
    }

    class Trabajador extends Persona{
    int salario;

    public void salario(int numeroSalario){
        System.out.println("Salario"+numeroSalario);
    }
}





