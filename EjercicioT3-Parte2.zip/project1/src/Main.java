import javax.xml.validation.SchemaFactoryConfigurationError;

public class Main {

    public static void main(String[] args) {
    Coche miCoche = new Coche();
    miCoche.incrementarPuerta();
    System.out.println(miCoche.Puertas);
    }
}

class Coche {
        public int Puertas = 3;
        public void incrementarPuerta() {
         this.Puertas++;
        }
}
