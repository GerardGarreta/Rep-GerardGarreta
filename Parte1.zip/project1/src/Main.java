public class Main {
    public static void main(String[] args) {
       int a = 10;
       int b =20;
       int c =40;
        suma(a,b,c);

    }

    public static void suma(int a, int b, int c){
        a = a +10;
        b = b +10;
        c = c +10;
        System.out.println(a+b+c);
    }

}